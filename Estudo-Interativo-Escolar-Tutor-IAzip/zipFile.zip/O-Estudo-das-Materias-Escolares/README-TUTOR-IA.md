# Ativar o Tutor IA no Replit

O site foi preparado para rodar com um pequeno servidor Node.js e a Gemini API. A chave fica no servidor, nunca no HTML/JavaScript público.

## 1. Importar os arquivos
1. Faça uma cópia/backup do projeto atual no Replit.
2. Envie os arquivos deste ZIP para o projeto, substituindo os arquivos quando solicitado.
3. Confira que `server.js`, `package.json` e `js/ia.js` ficaram na raiz/na pasta indicada.

## 2. Criar uma chave Gemini
1. Entre no Google AI Studio com a conta Google apropriada: https://aistudio.google.com/app/apikey
2. Crie uma chave de API, se sua conta/modelo tiver acesso disponível.
3. Não envie a chave no chat e não a coloque em arquivos do site.

## 3. Guardar a chave no Replit
1. Abra **Secrets** (ícone de cadeado / ferramenta de variáveis de ambiente) no Replit.
2. Adicione `GEMINI_API_KEY` e cole a chave como valor.
3. Opcionalmente, adicione `GEMINI_MODEL` com o nome de um modelo disponível para sua chave. O padrão é `gemini-2.5-flash`.

A disponibilidade de modelos, cotas gratuitas e limites pode mudar; talvez seja necessário escolher outro modelo disponível na sua conta. Não habilite cobrança sem entender os custos.

## 4. Iniciar
O arquivo `.replit` já aponta para `npm start`, que executa `node server.js`. Clique em **Run**. O servidor usa a porta fornecida pelo Replit ou a porta 5000.

## 5. Testar
Abra `ia.html`, envie uma pergunta escolar curta e aguarde. Se a chave não estiver configurada, a página mostrará um aviso. Se a cota gratuita estiver esgotada ou o modelo não estiver liberado, aparecerá uma mensagem de erro apropriada.

## Observações
- O servidor limita o tamanho das perguntas e o número de requisições por minuto por conexão como proteção básica.
- Antes de publicar para uso público, revise a segurança e os limites; isso é uma integração inicial de projeto escolar, não um serviço de produção completo.
- Não peça aos estudantes que enviem senhas, dados pessoais ou informações privadas.
