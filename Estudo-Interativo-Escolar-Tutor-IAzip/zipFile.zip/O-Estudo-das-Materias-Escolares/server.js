const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');

const ROOT = __dirname;
const PORT = Number(process.env.PORT || 5000);
const API_KEY = process.env.GEMINI_API_KEY;
const MODEL = process.env.GEMINI_MODEL || 'gemini-2.5-flash';
const MIME = {
  '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8', '.json': 'application/json; charset=utf-8',
  '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg',
  '.svg': 'image/svg+xml', '.ico': 'image/x-icon', '.webp': 'image/webp', '.pdf': 'application/pdf'
};
const requestCounts = new Map();

function sendJson(res, status, data) {
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
  res.end(JSON.stringify(data));
}

function readJson(req) {
  return new Promise((resolve, reject) => {
    let body = '';
    req.on('data', chunk => {
      body += chunk;
      if (body.length > 20_000) {
        reject(new Error('A mensagem é muito grande.')); 
        req.destroy();
      }
    });
    req.on('end', () => {
      try { resolve(JSON.parse(body || '{}')); }
      catch { reject(new Error('Não consegui ler sua mensagem. Tente novamente.')); }
    });
    req.on('error', reject);
  });
}

async function handleChat(req, res) {
  const ip = req.socket.remoteAddress || 'unknown';
  const now = Date.now();
  const record = requestCounts.get(ip) || { start: now, count: 0 };
  if (now - record.start > 60_000) { record.start = now; record.count = 0; }
  record.count += 1;
  requestCounts.set(ip, record);
  if (record.count > 15) return sendJson(res, 429, { error: 'Muitas perguntas em pouco tempo. Aguarde um minuto e tente novamente.' });

  let payload;
  try { payload = await readJson(req); }
  catch (error) { return sendJson(res, 400, { error: error.message }); }

  const question = typeof payload.question === 'string' ? payload.question.trim() : '';
  if (!question) return sendJson(res, 400, { error: 'Digite uma pergunta antes de enviar.' });
  if (question.length > 4000) return sendJson(res, 400, { error: 'Sua pergunta ficou muito longa. Use até 4.000 caracteres.' });
  if (!API_KEY) return sendJson(res, 503, { error: 'A chave da IA ainda não foi configurada no Replit. Adicione GEMINI_API_KEY em Secrets e reinicie o projeto.' });

  const subject = typeof payload.subject === 'string' ? payload.subject.slice(0, 40) : 'conteúdos escolares';
  const prompt = `Você é o Tutor IA do projeto escolar Estudo Interativo Escolar, para alunos do Ensino Médio no Brasil.\n\nObjetivo: explicar de maneira didática, acolhedora e adequada à idade, principalmente Matemática, Física, Química e Biologia. Use português brasileiro, organize respostas longas em passos e dê exemplos quando ajudarem. Em exercícios, explique o raciocínio em vez de apenas entregar respostas. Se não souber algo, diga isso com honestidade. Não invente fontes nem afirme que consultou materiais que não recebeu. Para assuntos fora das matérias, responda brevemente e redirecione gentilmente aos estudos.\nMatéria selecionada: ${subject}.\nPergunta do estudante: ${question}`;

  try {
    const apiResponse = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(MODEL)}:generateContent`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'x-goog-api-key': API_KEY },
      body: JSON.stringify({
        contents: [{ role: 'user', parts: [{ text: prompt }] }],
        generationConfig: { temperature: 0.5, maxOutputTokens: 900 }
      }),
      signal: AbortSignal.timeout(45_000)
    });
    const data = await apiResponse.json().catch(() => ({}));
    if (!apiResponse.ok) {
      console.error('Gemini API status:', apiResponse.status, data?.error?.status || 'API_ERROR');
      if (apiResponse.status === 429) return sendJson(res, 429, { error: 'A cota gratuita pode ter sido atingida. Aguarde um pouco e tente novamente.' });
      if (apiResponse.status === 401 || apiResponse.status === 403) return sendJson(res, 502, { error: 'A API não aceitou a chave ou não liberou acesso ao modelo. Confira a chave, o modelo e a disponibilidade da cota no Google AI Studio.' });
      return sendJson(res, 502, { error: 'A IA não conseguiu responder agora. Tente novamente em instantes.' });
    }
    const answer = (data.candidates || []).flatMap(c => c.content?.parts || []).map(p => p.text || '').join('\n').trim();
    if (!answer) return sendJson(res, 502, { error: 'A IA retornou uma resposta vazia. Tente reformular a pergunta.' });
    return sendJson(res, 200, { answer });
  } catch (error) {
    console.error('Erro ao consultar Gemini:', error.name || 'RequestError');
    return sendJson(res, 502, { error: 'Não consegui conectar à IA agora. Verifique a conexão e tente novamente.' });
  }
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
  if (req.method === 'POST' && url.pathname === '/api/chat') return handleChat(req, res);
  if (url.pathname.startsWith('/api/')) return sendJson(res, 404, { error: 'Rota não encontrada.' });
  if (req.method !== 'GET' && req.method !== 'HEAD') return sendJson(res, 405, { error: 'Método não permitido.' });

  let pathname;
  try { pathname = decodeURIComponent(url.pathname); }
  catch { return sendJson(res, 400, { error: 'Endereço inválido.' }); }
  if (pathname === '/') pathname = '/index.html';
  const filePath = path.resolve(ROOT, `.${pathname}`);
  if (filePath !== ROOT && !filePath.startsWith(ROOT + path.sep)) return sendJson(res, 403, { error: 'Acesso negado.' });
  fs.stat(filePath, (err, stat) => {
    if (err || !stat.isFile()) { res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' }); return res.end('Página não encontrada.'); }
    res.writeHead(200, { 'Content-Type': MIME[path.extname(filePath).toLowerCase()] || 'application/octet-stream', 'X-Content-Type-Options': 'nosniff' });
    if (req.method === 'HEAD') return res.end();
    fs.createReadStream(filePath).pipe(res);
  });
});

server.listen(PORT, '0.0.0.0', () => console.log(`Estudo Interativo Escolar disponível na porta ${PORT}`));
