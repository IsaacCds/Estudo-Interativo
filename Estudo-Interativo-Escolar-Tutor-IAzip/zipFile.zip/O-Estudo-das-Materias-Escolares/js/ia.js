(() => {
  const input = document.getElementById('ia-question');
  const sendButton = document.getElementById('ia-send');
  const chat = document.querySelector('.ia-chat');
  const status = document.getElementById('ia-status-message');
  if (!input || !sendButton || !chat) return;

  const subjectMatchers = [
    [/matem[aá]tica|n[uú]meros|equ[aá]ç|polin[oô]mio|funç[aã]o/i, 'Matemática'],
    [/f[ií]sica|forç|velocidade|energia|eletricidade/i, 'Física'],
    [/qu[ií]mica|[áa]tomo|mol[eé]cula|reaç[aã]o|org[aâ]nica/i, 'Química'],
    [/biologia|c[eé]lula|gen[eé]tica|ecossistema|organismo/i, 'Biologia']
  ];
  function getSubject(question) {
    for (const [pattern, subject] of subjectMatchers) if (pattern.test(question)) return subject;
    return 'conteúdos escolares';
  }
  function addMessage(text, who) {
    const wrapper = document.createElement('div');
    wrapper.className = `ia-message ${who === 'user' ? 'ia-message-user' : 'ia-message-bot'}`;
    const avatar = document.createElement('div');
    avatar.className = 'ia-message-avatar';
    avatar.textContent = who === 'user' ? '👤' : '🤖';
    const content = document.createElement('div');
    content.className = 'ia-message-content';
    const name = document.createElement('strong');
    name.textContent = who === 'user' ? 'Você' : 'Tutor IA';
    const paragraph = document.createElement('p');
    paragraph.textContent = text;
    content.append(name, paragraph);
    wrapper.append(avatar, content);
    chat.appendChild(wrapper);
    wrapper.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    return paragraph;
  }
  async function sendQuestion() {
    const question = input.value.trim();
    if (!question || sendButton.disabled) {
      if (!question) { status.textContent = 'Digite sua dúvida antes de enviar.'; input.focus(); }
      return;
    }
    addMessage(question, 'user');
    input.value = '';
    sendButton.disabled = true;
    sendButton.setAttribute('aria-busy', 'true');
    status.textContent = 'O Tutor IA está pensando…';
    const reply = addMessage('Estou preparando uma explicação para você…', 'bot');
    try {
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ question, subject: getSubject(question) })
      });
      const data = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(data.error || 'Não foi possível obter uma resposta.');
      reply.textContent = data.answer;
      status.textContent = 'Resposta recebida. Pode mandar outra pergunta!';
    } catch (error) {
      reply.textContent = error.message || 'Ocorreu um erro. Tente novamente.';
      status.textContent = 'Não foi possível concluir a pergunta.';
    } finally {
      sendButton.disabled = false;
      sendButton.removeAttribute('aria-busy');
      input.focus();
    }
  }
  sendButton.addEventListener('click', sendQuestion);
  input.addEventListener('keydown', event => {
    if (event.key === 'Enter' && !event.shiftKey) { event.preventDefault(); sendQuestion(); }
  });
  document.querySelectorAll('.ia-suggestion-list [data-question]').forEach(button => {
    button.addEventListener('click', () => { input.value = button.dataset.question || ''; input.focus(); });
  });
})();
